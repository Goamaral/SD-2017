Requesitos extra
	DataServer.jar
		ficheiro ojbc14.jar presente na mesma path que o DataServer.jar
		base de dados oracle:
			Nome base de dados -> bd
			Password base de dados -> bd

	Para todos os jar
		ficheiro policy.all tem que estar presente

Execucao
	Para executar qualque jar:
		java -jar Package.jar
